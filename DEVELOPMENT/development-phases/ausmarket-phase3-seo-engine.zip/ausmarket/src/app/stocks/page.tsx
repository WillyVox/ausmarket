import type { Metadata } from "next";
import { StockSearch } from "@/components/stock-search";
import { POPULAR_STOCKS } from "@/lib/stocks/data";

export const metadata: Metadata = {
  title: "ASX Share Prices — Search Australian Stocks",
  description:
    "Search Australian (ASX) share prices, charts and statistics, or browse popular ASX stocks like BHP, CBA and CSL.",
};

export default function StocksIndexPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-2xl font-semibold text-navy-900">ASX Share Prices</h1>
      <p className="mt-1 text-sm text-slate-500">
        Search for a company or browse popular ASX-listed stocks below.
      </p>

      <div className="mt-6">
        <StockSearch />
      </div>

      <section className="mt-10">
        <h2 className="text-lg font-semibold text-navy-900">Popular ASX Stocks</h2>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {POPULAR_STOCKS.map((s) => (
            <a
              key={s.symbol}
              href={`/stocks/${s.symbol.toLowerCase()}`}
              className="rounded-lg border border-slate-200 px-4 py-3 text-sm hover:border-slate-300"
            >
              <span className="font-medium text-navy-900">{s.symbol}</span>{" "}
              <span className="text-slate-500">{s.name}</span>
            </a>
          ))}
        </div>
      </section>

      <section className="mt-10 rounded-lg border border-slate-200 p-5">
        <p className="text-sm text-slate-700">
          Ready to start trading ASX shares?
        </p>
        <a
          href="/compare/share-trading-platforms"
          className="mt-2 inline-block rounded-md bg-navy-900 px-4 py-2 text-sm font-medium text-white"
        >
          Compare Platforms
        </a>
      </section>
    </div>
  );
}
