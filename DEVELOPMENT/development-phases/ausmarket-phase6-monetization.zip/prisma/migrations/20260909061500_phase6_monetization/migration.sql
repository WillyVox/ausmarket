/*
  Phase 6 — Monetization. Hand-authored in a sandbox with no
  DATABASE_URL / network access (same caveat as the Phase 4 migration
  before it) — run `npx prisma migrate dev` locally to have Prisma
  verify this against your actual schema drift before applying to any
  real database, or regenerate it from scratch if it disagrees.

  - Adds Role enum + User.role, defaulting existing rows to USER.
  - Adds creative fields + timestamps to AdPlacement so a "house_ad"
    row has something to actually render (the model previously had no
    content fields at all).
*/

-- CreateEnum
CREATE TYPE "Role" AS ENUM ('USER', 'ADMIN');

-- AlterTable
ALTER TABLE "User" ADD COLUMN "role" "Role" NOT NULL DEFAULT 'USER';

-- AlterTable
ALTER TABLE "AdPlacement"
  ADD COLUMN "headline" TEXT,
  ADD COLUMN "body" TEXT,
  ADD COLUMN "ctaLabel" TEXT,
  ADD COLUMN "ctaHref" TEXT,
  ADD COLUMN "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD COLUMN "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
